CREATE DATABASE IF NOT EXISTS appointment_system;
USE appointment_system;

CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    appointment_date DATE,
    appointment_time TIME,
    service VARCHAR(100)
);
