<?php
// Alternative admin dashboard layout
?>