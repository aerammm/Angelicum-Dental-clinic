<?php
$conn = new mysqli("localhost", "root", "", "appointment_system");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $date = $_POST["date"];
    $time = $_POST["time"];
    $service = $_POST["service"];

    $sql = "INSERT INTO appointments (name, email, appointment_date, appointment_time, service)
            VALUES ('$name', '$email', '$date', '$time', '$service')";

    if ($conn->query($sql) === TRUE) {
        echo "Appointment booked successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<form method="post">
    Name: <input type="text" name="name" required><br>
    Email: <input type="email" name="email" required><br>
    Date: <input type="date" name="date" required><br>
    Time: <input type="time" name="time" required><br>
    Service: <input type="text" name="service" required><br>
    <input type="submit" value="Book Appointment">
</form>
