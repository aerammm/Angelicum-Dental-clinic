<?php
echo "<h2>Welcome to the Appointment System</h2>";
echo "<a href='appointment-form.php'>Book an Appointment</a>";
?>
