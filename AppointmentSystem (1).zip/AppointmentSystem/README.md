# Appointment System

This is a basic appointment management system built in PHP.