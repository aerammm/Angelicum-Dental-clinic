<?php
// Display user inquiries here
?>